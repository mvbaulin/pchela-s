(function(){
	window.variables = {
		mainNav: document.querySelector('.site-menu__navigation'),
		menuBar: document.querySelector('.site-menu'),
		menuNumber: document.querySelector('.site-menu__numbers') ,
		mainSlider: document.querySelector('.main-slider'),
		carPrice: document.querySelector('#car-price')
	};
})()
